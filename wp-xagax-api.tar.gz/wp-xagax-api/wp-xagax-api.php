<?php
/*
Plugin Name: wp-xagax-api
Plugin URI: http://yourdomain.com/
Description: A simple hello world wordpress plugin
Version: 1.0
Author: CarlaAres
Author URI: http://yourdomain.com
License: GPL
*/


if (!function_exists('getallheaders')) 
{
    function getallheaders() 
    {
       foreach ($_SERVER as $name => $value) 
       {
           if (substr($name, 0, 5) == 'HTTP_') 
           {
               $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
           }
       }
       return $headers;
    }
}


global $wpr;
$wpr = array();

// Plugin Settings
$wpr['reserved_requests'] = array("new_user");
$wpr['reserved_requests_without_template'] = array("new_user");


// Render User Pages / Return Requests
function wpr_xagax_return() {
  global $wpr;

	require_once 'lib/REST.inc.php';
	$WPREST = new WPREST ();
}

// Check URL query to see if we need to jump straight to API Core or not
function wpr_check_query($wp_query) {
	global $wpr;
  if ($wp_query->query_vars['pagename'] == "api") {
		wpr_xagax_return();
		exit();
	}
}

// Adding the request var so that WP recognizes it
function add_query_var($vars)
{
	global $wpr,$wp_query;
    array_push($vars, 'request');
    return $vars;
}


// Adding a new rule to WordPress rewrite system
function insert_rewrite_rule($rules)
{
	$newrules = array();
	$newrules['(api)/(.*)$'] = 'index.php?pagename=$matches[1]&request=$matches[2]';
	return $newrules + $rules;
}

// Create shortcodes
add_shortcode('REST_xagax_return','wpr_xagax_return');
// Add Filters
add_filter('rewrite_rules_array','insert_rewrite_rule');
add_filter('query_vars','add_query_var');
// Add Actions
add_action("parse_query","wpr_check_query");

?>
